<?php

/**
 * @file
 * A single location to store configuration.
 */

// get these by registering at http://dev.mendeley.com
define('CONSUMER_KEY', 		'');
define('CONSUMER_SECRET', 	'');

// Set HTTP proxy (if needed)
define ('HTTP_PROXY', NULL);

// Callback URL
define('OAUTH_CALLBACK', '');

?>