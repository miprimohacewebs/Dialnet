<?php

/**
 * @file
 * A single location to store configuration.
 */

// get these by registering at http://dev.mendeley.com
define('CONSUMER_KEY', 		'');
define('CONSUMER_SECRET', 	'');

define ('HTTP_PROXY', NULL);

?>